README
============================================================

Name:
	Vector Sparse Representation of Color Image Using Quaternion Matrix Analysis


Release date:
	2015-09-16

Author:
	Yi Xu, Licheng Yu, Hongteng Xu, Hao Zhang, Truong Nguyen 
	
Copyright (c) 2015:
	Yi Xu, xuyi@sjtu.edu.cn
	
Description:

The codes can only be used for academic research. 
Please cite following papers for utilizing the codes.

@article{xu2015vector,
  title={Vector Sparse Representation of Color Image Using Quaternion Matrix Analysis},
  author={Xu, Yi and Yu, Licheng and Xu, Hongteng and Zhang, Hao and Nguyen, Truong},
  journal={Image Processing, IEEE Transactions on},
  volume={24},
  number={4},
  pages={1315--1329},
  year={2015},
  publisher={IEEE}
}

@inproceedings{licheng2013quaternion,
  title={Quaternion-based sparse representation of color image},
  author={Licheng, Yu and Xu, Yi and Xu, Hongteng and Zhang, Hao},
  booktitle={Multimedia and Expo (ICME), 2013 IEEE International Conference on},
  pages={1--7},
  year={2013},
  organization={IEEE}
}

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

1. Folder of Quaternion dictionary training in KQSVD

A. The main functions include main_DictTraining.m and main_Reconstruction.m.
main_DictTraining.m: Calling function for dictionary training step in K-QSVD algorithm. The trained disctionary is generated in folder of "training result".
main_Reconstruction.m: Calling function for color image reconstruction using K-QSVD algorithm.

B. The other called functions 
Type "help XXX" will show the help information of this function. 

C. Subfolder of Dataset classifying
For Storage of the input training image and reconstruction image. 
Here the training images are “flower” while the reconstructed images are “animal”, which verifies the robustness of our method to the variety of patches’ source. 

D. Subfolder of Training result
For Storage of the trained dictionary.


2. Folder of Color Image denoising using KQSVD 

A. main_Denoising.m: Calling function for Color Image De-noising using K-QSVD.

B. The other called functions
Type "help XXX" will show the help information of this function.

C. Subfolder of original
For Storage of the input image.

D. Subfolder of Training result
For Storage of the trained dictionary without noise.
